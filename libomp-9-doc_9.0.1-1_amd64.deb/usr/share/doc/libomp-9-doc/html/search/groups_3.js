var searchData=
[
  ['parallel_20_28fork_2fjoin_29_352',['Parallel (fork/join)',['../group__PARALLEL.html',1,'']]]
];
