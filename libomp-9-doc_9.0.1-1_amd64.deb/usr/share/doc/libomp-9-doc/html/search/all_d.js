var searchData=
[
  ['sched_5ftype_170',['sched_type',['../group__WORK__SHARING.html#ga56ebd4fa33cbb0497e6157bb3f04d0e2',1,'kmp.h']]],
  ['set_171',['set',['../classkmp__flag.html#aa9158e2c4191ad98cdf77f95917001cc',1,'kmp_flag']]],
  ['startup_20and_20shutdown_172',['Startup and Shutdown',['../group__STARTUP__SHUTDOWN.html',1,'']]],
  ['statistics_20gathering_20from_20omptb_173',['Statistics Gathering from OMPTB',['../group__STATS__GATHERING.html',1,'']]],
  ['stats_5fflags_5fe_174',['stats_flags_e',['../group__STATS__GATHERING.html#ga438c2840cc2d516238ea3eb0f4c116b3',1,'kmp_stats.h']]],
  ['stats_5fstate_5fe_175',['stats_state_e',['../group__STATS__GATHERING.html#gaceceb28b590e725a5106b6c90a451243',1,'kmp_stats.h']]],
  ['store_176',['store',['../classkmp__flag.html#a62d58938451d206a1b76df304ee62134',1,'kmp_flag']]],
  ['synchronization_177',['Synchronization',['../group__SYNCHRONIZATION.html',1,'']]]
];
