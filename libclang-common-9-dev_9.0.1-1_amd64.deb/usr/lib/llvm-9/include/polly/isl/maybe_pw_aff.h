#ifndef ISL_MAYBE_PW_AFF_H
#define ISL_MAYBE_PW_AFF_H

#define ISL_TYPE	isl_pw_aff
#include <isl/maybe_templ.h>
#undef ISL_TYPE

#endif
